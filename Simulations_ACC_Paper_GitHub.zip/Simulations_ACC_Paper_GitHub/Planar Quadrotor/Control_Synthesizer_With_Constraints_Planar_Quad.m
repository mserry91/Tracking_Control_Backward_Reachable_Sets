function [u_ast_Array] = Control_Synthesizer_With_Constraints_Planar_Quad(n,m,N_extend,N_alpha,N_iter,iter_cr,iter_max,X0,x_sample,dist_target,Ul,Uu)
c_input=0.5*(Ul+Uu);
r_input=0.5*(-Ul+Uu);

iter=0;
Dist_LTV_f=inf;
u_ast_Array=zeros(m,N_extend);

while Dist_LTV_f>dist_target && iter<=iter_max
iter=iter+1;
if iter==1
u=c_input;
elseif iter>1 && iter<=iter_cr
u=c_input+(2*rand-1)*r_input;
else    
u=Ul+(Uu-Ul).*rand(m,1);    
end

for j=1:N_extend
    u_ast_Array(:,j)=u;
end


u_o=u_ast_Array;
Dist=ones(1,N_iter);
for j=1:N_iter
u_ast_Array =  Control_Min_Energy_Active_Constraints_Planar_Quad(n,m,N_extend,N_alpha,X0,x_sample,Ul,Uu,u_o);
Y=Extend_Planar_Quad(X0,N_extend,u_ast_Array);
Dist(j)=norm(Y-x_sample,2);
e=norm(u_ast_Array-u_o);
u_o=u_ast_Array;


     if  e<1e-4
         break;
     end

end
  

j_end=j;
Dist_LTV_f=Dist(j_end);

end



end

