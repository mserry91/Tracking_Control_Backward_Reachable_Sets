function [H1,H2,H3,H4,H5,H6] = Hessian_Planar_Quad(x,Rx,~,~)


Dt=0.01;
g=9.81;

phi_interval=interval(x(3)-Rx(3),x(3)+Rx(3));
cs_phi_interval=abs(cos(phi_interval));
sup_cs_phi_interval=cs_phi_interval.sup;
sn_phi_interval=abs(sin(phi_interval));
sup_sn_phi_interval=sn_phi_interval.sup;
vx=x(4);
vz=x(5);
vxmax=max([abs(vx-Rx(4)),abs(vx+Rx(4))]);
vzmax=max([abs(vz-Rx(5)),abs(vz+Rx(5))]);


H1 =[ 0, 0,                               0,            0,            0, 0, 0, 0;
      0, 0,                               0,            0,            0, 0, 0, 0;
      0, 0, Dt*(vxmax*sup_cs_phi_interval + vzmax*sup_sn_phi_interval), Dt*sup_sn_phi_interval, Dt*sup_cs_phi_interval, 0, 0, 0;
      0, 0,                    Dt*sup_sn_phi_interval,            0,            0, 0, 0, 0;
      0, 0,                    Dt*sup_cs_phi_interval,            0,            0, 0, 0, 0;
      0, 0,                               0,            0,            0, 0, 0, 0;
      0, 0,                               0,            0,            0, 0, 0, 0;
      0, 0,                               0,            0,            0, 0, 0, 0];

  
%   H1 =
%  
% [ 0, 0,                               0,            0,            0, 0, 0, 0]
% [ 0, 0,                               0,            0,            0, 0, 0, 0]
% [ 0, 0, -Dt*(vx*cos(phi) - vz*sin(phi)), -Dt*sin(phi), -Dt*cos(phi), 0, 0, 0]
% [ 0, 0,                    -Dt*sin(phi),            0,            0, 0, 0, 0]
% [ 0, 0,                    -Dt*cos(phi),            0,            0, 0, 0, 0]
% [ 0, 0,                               0,            0,            0, 0, 0, 0]
% [ 0, 0,                               0,            0,            0, 0, 0, 0]
% [ 0, 0,                               0,            0,            0, 0, 0, 0]
  
  
  
 
H2 =[ 0, 0,                               0,           0,            0, 0, 0, 0;
      0, 0,                               0,           0,            0, 0, 0, 0;
      0, 0, Dt*(vzmax*sup_cs_phi_interval + vxmax*sup_sn_phi_interval), Dt*sup_cs_phi_interval, Dt*sup_sn_phi_interval, 0, 0, 0;
      0, 0,                     Dt*sup_cs_phi_interval,           0,            0, 0, 0, 0;
      0, 0,                    Dt*sup_sn_phi_interval,           0,            0, 0, 0, 0;
      0, 0,                               0,           0,            0, 0, 0, 0;
      0, 0,                               0,           0,            0, 0, 0, 0;
      0, 0,                               0,           0,            0, 0, 0, 0];
 
 
  
%   H2 =
%  
% [ 0, 0,                               0,           0,            0, 0, 0, 0]
% [ 0, 0,                               0,           0,            0, 0, 0, 0]
% [ 0, 0, -Dt*(vz*cos(phi) + vx*sin(phi)), Dt*cos(phi), -Dt*sin(phi), 0, 0, 0]
% [ 0, 0,                     Dt*cos(phi),           0,            0, 0, 0, 0]
% [ 0, 0,                    -Dt*sin(phi),           0,            0, 0, 0, 0]
% [ 0, 0,                               0,           0,            0, 0, 0, 0]
% [ 0, 0,                               0,           0,            0, 0, 0, 0]
% [ 0, 0,                               0,           0,            0, 0, 0, 0]
 
 
  
  
H3 =zeros(8,8);
  
 
H4 =[ 0, 0,             0, 0,  0,  0, 0, 0;
      0, 0,             0, 0,  0,  0, 0, 0;
      0, 0, Dt*g*sup_sn_phi_interval, 0,  0,  0, 0, 0;
      0, 0,             0, 0,  0,  0, 0, 0;
      0, 0,             0, 0,  0, Dt, 0, 0;
      0, 0,             0, 0, Dt,  0, 0, 0;
      0, 0,             0, 0,  0,  0, 0, 0;
      0, 0,             0, 0,  0,  0, 0, 0];
  
%   H4 =
%  
% [ 0, 0,             0, 0,  0,  0, 0, 0]
% [ 0, 0,             0, 0,  0,  0, 0, 0]
% [ 0, 0, Dt*g*sin(phi), 0,  0,  0, 0, 0]
% [ 0, 0,             0, 0,  0,  0, 0, 0]
% [ 0, 0,             0, 0,  0, Dt, 0, 0]
% [ 0, 0,             0, 0, Dt,  0, 0, 0]
% [ 0, 0,             0, 0,  0,  0, 0, 0]
% [ 0, 0,             0, 0,  0,  0, 0, 0]
  
 
 
H5 = [ 0, 0,             0,   0, 0,   0, 0, 0;
       0, 0,             0,   0, 0,   0, 0, 0;
       0, 0, Dt*g*sup_cs_phi_interval,   0, 0,   0, 0, 0;
       0, 0,             0,   0, 0, Dt, 0, 0;
       0, 0,             0,   0, 0,   0, 0, 0;
       0, 0,             0, Dt, 0,   0, 0, 0;
       0, 0,             0,   0, 0,   0, 0, 0;
       0, 0,             0,   0, 0,   0, 0, 0];
   
   
   %H5 =
 
% [ 0, 0,             0,   0, 0,   0, 0, 0]
% [ 0, 0,             0,   0, 0,   0, 0, 0]
% [ 0, 0, Dt*g*cos(phi),   0, 0,   0, 0, 0]
% [ 0, 0,             0,   0, 0, -Dt, 0, 0]
% [ 0, 0,             0,   0, 0,   0, 0, 0]
% [ 0, 0,             0, -Dt, 0,   0, 0, 0]
% [ 0, 0,             0,   0, 0,   0, 0, 0]
% [ 0, 0,             0,   0, 0,   0, 0, 0]
   
   
 
 
H6 =zeros(8,8);
 


 
 


 
 

 
 

 
 


  
end

