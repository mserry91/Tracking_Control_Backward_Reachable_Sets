

load('Planar_Quad_Data_For_PlottingA')


Xs=zonotope(Cs,Gs);
%plot(Xs,[1 2],'EdgeColor','none','FaceColor','g','FaceAlpha',.5)
hold on


NN=cell(numNodes+1,1);
for i=1:numNodes+1
NN{i}=zonotope(X(:,i),diag(Rx(:,i)));
%plot(NN{i},[1 2],'EdgeColor',0.8*[0.3010 0.7450 0.9330],'FaceColor',[0.3010 0.7450 0.9330],'FaceAlpha',0.1)
plot(NN{i},[1 2],'EdgeColor','none','FaceColor',[0.3010 0.7450 0.9330],'FaceAlpha',0.1)

hold on
end







Xt=zonotope(Ct,Gt);
plot(Xt,[1 2],'EdgeColor','none','FaceColor','b')


Xu=cell(1,Nu);

for i=1:Nu
Xu{i}=zonotope([CuArray(:,i),GuArray(:,:,i)]);
plot(Xu{i},[1 2],'EdgeColor','none','FaceColor','r')
end


for ind=numNodes+1:-1:1
%plot(T{ind},[1 2],'EdgeColor',[0.3,0.3,0.3],'FaceColor',[0.5,0.5,0.5],'FaceAlpha',0.1)
plot(T{ind},[1 2],'EdgeColor',[0.3,0.3,0.3],'FaceColor',[0.5,0.5,0.5],'FaceAlpha',0.05)

hold on
end


scatter(X_sample1(1,:),X_sample1(2,:),20,'o','markeredgecolor','none','markerfacecolor',[0.8500 0.3250 0.0980])
%scatter(X_sample2(1,:),X_sample2(2,:),'dm')
%scatter(X_sample3(1,:),X_sample3(2,:),'dm')
scatter(X(1,:),X(2,:),20,'o','markerfacecolor','k','markeredgecolor','none')
%scatter(X(1,1),X(2,1),'filled','k')


xlabel('$x_{1}$','interpreter','latex')
ylabel('$x_{2}$','interpreter','latex')
set(gca,'fontsize',15)
set(gca,'ticklabelinterpreter','latex')
xlim([Xsl(1),Xsu(1)])
ylim([Xsl(2),Xsu(2)])
%grid on
box on

t_online=t_online1;
%t_online=(t_online3+t_online2+t_online1)/3;

warning('planning, state and input boxes, BRS computations, and online computations times are %0.2f, %0.2f, %0.2f, %0.2f seconds',t_planning,t_boxes,t_tracking,t_online)
warning('Number of nodes is %d',numNodes)