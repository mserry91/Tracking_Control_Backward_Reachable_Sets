function [A] = G_d_planar_quad(~)

Dt=0.01;
%g=9.81;
m=0.486;
l=0.25;
J=0.00383;


%The continuous dynamics of the planar quadrotor are given by
%pxd=vx*cos(phi)-vz*sin(phi);
%pzd=vx*sin(phi)+vz*cos(phi);
%phid=phid;
%vxd=vz*phid-g*sing(phi);
%vzd=-vx*phid-g*cos(phi)+(1/m)*(u1+u2);
%phidd=(l/J)*(u1-u2);

% The discrete-time dynamics are given by
% px=pxp+Dt*(vxp*cos(phip)-vzp*sin(phip));
% pz=pzp+Dt*(vxp*sin(phip)+vzp*cos(phip));
% phi=phip+Dt*phidp;
% vx=vxp+Dt*(vzp*phidp-g*sing(phip));
% vz=vzp+Dt*(vxp*phidp-g*cos(phip)+(1/m)*(u1+u2));
% phid=phidp+Dt*((l/J)*(u1-u2));

 
% x(1)=px;
% x(2)=pz;
% x(3)=phi;
% x(4)=vx;
% x(5)=vz;
% x(6)=phid;

A=Dt*[0 0;
      0 0;
      0 0;
      0 0;
      (1/m) (1/m);
      (l/J) -(l/J)];
 
end

