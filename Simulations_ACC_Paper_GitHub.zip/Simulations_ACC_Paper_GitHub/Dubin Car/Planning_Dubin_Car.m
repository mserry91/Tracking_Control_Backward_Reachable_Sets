% This code is for RRT path planning of the Dubin's car system
% of the form x+=f(x)+g(x)*u with safe set (box) Xs,
% unsafe region (union of boxes) Xu, initial point x0 in Xs, 
% and target set (box) Xt. A robustness margin delta is used to inflate and
% deflate the unsafe and safe sets, respectively.

clc
clear all
close all


% system dimension 
n=3;
m=2;

% maximum number of iterations
N_iter=100;

N_extend=50;

% maximum number of vertices in RRT plans
Nv=N_iter*(1+N_extend);


% robustness margins
delta_vector=[0.2;0.2;pi/9];





% safe set Xs

Xsl=[0;0;-pi/2];

Xsu=[5;5;pi/2];


Cs=0.5*(Xsl+Xsu);
Ds=0.5*(Xsu-Xsl)-delta_vector;
Gs=diag(Ds);


% Initial Condition

X0=[0.5;4.5;-pi/4];

sX=size(X0);

% system dimension
n=sX(1);


% Target set Xt 

Xtl=[3.5;4.5;-pi/5];
Xtu=[5;5;pi/5];
Ct=0.5*(Xtl+Xtu);
Dt=0.5*(Xtu-Xtl)-delta_vector;
Gt=diag(Dt);


% Unsafe set Xu
XulArray=[1.5;1;-pi/2];
XuuArray=[3;2;pi/2];
XulArray=[XulArray, [1.5;3.5;-pi/2]];
XuuArray=[XuuArray,[2.5;5;pi/2]];
XulArray=[XulArray, [3.5;2;-pi/2]];
XuuArray=[XuuArray,[4.5;3.5;pi/2]];

sXu=size(XulArray);
Nu=sXu(2);

CuArray=0.5*(XulArray+XuuArray);
DuArray=0.5*(XuuArray-XulArray)+delta_vector;
GuArray=zeros(n,n,Nu);
GuiArray=zeros(n,n,Nu);

for j=1:Nu
GuArray(:,:,j)=diag(DuArray(:,j));
end





% control input set U
uxl=0;
%uxl=0;
uxu=0.08;

uyl=-0.05;
uyu=0.05;

epsu_vector=[0.02;0.02]; % parameter for deflating input set

Ul=[uxl;uyl];

Uu=[uxu;uyu];
%input dimension
sizeU=size(Uu);
nu=sizeU(1);

c_input=0.5*(Ul+Uu);
G_input_def=0.5*((Uu-epsu_vector)-(Uu+epsu_vector));
U_norm=norm([c_input,G_input_def],inf);









tic

%initializing the RRT Tree and associated tree structures
Tree=zeros(n,Nv);
F_d_Tree=zeros(n,Nv);
G_d_Tree=zeros(n,nu,Nv);
G_d_Norm_Tree=zeros(1,Nv);
Reachset_Center_Tree=zeros(n,Nv);
Reachset_Safe_Margin_Tree=zeros(n,Nv);
Reachset_Center_Feasability_Tree=zeros(1,Nv);
Nodes=ones(1,N_iter);
Images=ones(1,N_iter);


ind=1;
ind_iter=0;
Tree(:,1)=X0; % adding initial point to the tree.
F_d_Tree(:,1)=F_d(Tree(:,1));
G_d_Tree(:,:,1)=G_d(Tree(:,1));
G_d_Norm_Tree(1)=norm(G_d_Tree(:,:,1),inf);

Reachset_Center_Tree(:,1)=F_d_Tree(:,1)+G_d_Tree(:,:,1)*c_input;
Reachset_Center_Feasability_Tree(1)=Safety_Check(Reachset_Center_Tree(:,1),Cs,Gs,CuArray,GuArray);
Reachset_Safe_Margin_Tree(:,1)=Safety_Radius(Reachset_Center_Tree(:,1),Cs,Gs,Ds,CuArray,GuArray,DuArray);


dist_T=300;





% Constraints for LP,
%the variable to solve for is X=[d;b;u], where b=|xs-F(xn)-G(xn)*u|.
% There are 6 matrix inequalities, the first two get updated in each
% iteration.
f=[1,zeros(1,n+nu)]; %objective function to be minimized.
A3=[zeros(nu,1),zeros(nu,n),eye(nu,nu)];
B3=Uu-epsu_vector;
A4=[zeros(nu,1),zeros(nu,n),-eye(nu,nu)];
B4=-(Ul+epsu_vector);
A5=[zeros(n,1),-eye(n,n),zeros(n,nu)];
B5=zeros(n,1);
A6=[-1,ones(1,n),zeros(1,nu)];
B6=0;

options = optimoptions('linprog','Display','off');




while  ind<Nv 
    
    
 % generating a random sample 
 if ind<0.75*Nv
 x_sample=Xsl+(Xsu-Xsl).*rand(n,1);
 else
 x_sample=Xtl+(Xtu-Xtl).*rand(n,1);   
 end
 
 
 dist=100*norm(Xsu-Xsl,inf);
  for ind_dist=1:ind
    if  Reachset_Center_Feasability_Tree(ind_dist)==1
     dr=norm(x_sample-Reachset_Center_Tree(:,ind_dist),inf); 
     if dr<=dist
         ind_near=ind_dist;
        dist=dr;
     end
    end
 end
 
 x_near=Tree(:,ind_near);
 
 A1=[zeros(n,1),-eye(n,n),-G_d_Tree(:,:,ind_near)];
 B1=F_d_Tree(:,ind_near)-x_sample;
 A2=[zeros(n,1),-eye(n,n),G_d_Tree(:,:,ind_near)];
 B2=-F_d_Tree(:,ind_near)+x_sample;
 A7=[zeros(n,1),zeros(n,n),G_d_Tree(:,:,ind_near)];
 
 B7=Reachset_Safe_Margin_Tree(:,ind_near)+G_d_Tree(:,:,ind_near)*c_input;
 A8=[zeros(n,1),zeros(n,n),-G_d_Tree(:,:,ind_near)];
 B8=Reachset_Safe_Margin_Tree(:,ind_near)-G_d_Tree(:,:,ind_near)*c_input;
 A=[A1;A2;A3;A4;A5;A6;A7;A8];
 B=[B1;B2;B3;B4;B5;B6;B7;B8];
 X_opt=linprog(f,A,B,[],[],[],[],options);

 r=X_opt(1+n+1:end);
 x_new=F_d_Tree(:,ind_near)+G_d_Tree(:,:,ind_near)*r;
 

 
 

 ind=ind+1;
 Tree(:,ind)=x_new;
 F_d_Tree(:,ind)=F_d(x_new);
 G_d_Tree(:,:,ind)=G_d(x_new);
 G_d_Norm_Tree(ind)= norm(G_d_Tree(:,:,ind),inf);
 Nodes(ind-1)=ind_near;
 Images(ind-1)=ind;
 dist_T=norm(Gt\(x_new-Ct),inf);
 if dist_T<=1
 break;
 end
 
Reachset_Center_Tree(:,ind)=F_d(Tree(:,ind))+G_d(Tree(:,ind))*c_input;
Reachset_Center_Feasability_Tree(ind)=Safety_Check(Reachset_Center_Tree(:,ind),Cs,Gs,CuArray,GuArray);
Reachset_Safe_Margin_Tree(:,ind)=Safety_Radius(Reachset_Center_Tree(:,ind),Cs,Gs,Ds,CuArray,GuArray,DuArray);
 


% extending step
x_new_extend_p=x_new;

for ind_extend=1:N_extend
x_new_extend=F_d(x_new_extend_p)+G_d(x_new_extend_p)*r;
safetycheck=Safety_Check(x_new_extend,Cs,Gs,CuArray,GuArray); 
if safetycheck==1
 ind=ind+1;
 Tree(:,ind)=x_new_extend;
 F_d_Tree(:,ind)=F_d(x_new_extend);
 G_d_Tree(:,:,ind)=G_d(x_new_extend);
 G_d_Norm_Tree(ind)= norm(G_d_Tree(:,:,ind),inf);
 Nodes(ind-1)=ind-1;
 Images(ind-1)=ind;
 dist_T=norm(Gt\(x_new_extend-Ct),inf);
 Reachset_Center_Tree(:,ind)=F_d(Tree(:,ind))+G_d(Tree(:,ind))*c_input;
 Reachset_Center_Feasability_Tree(ind)=Safety_Check(Reachset_Center_Tree(:,ind),Cs,Gs,CuArray,GuArray);
 Reachset_Safe_Margin_Tree(:,ind)=Safety_Radius(Reachset_Center_Tree(:,ind),Cs,Gs,Ds,CuArray,GuArray,DuArray);
 x_new_extend_p=x_new_extend;
else
    break;
end

if dist_T<=1
 break;
end
 
end
 
 
 
    
end    
    
    











 
 
  if dist_T<=1
   warning('Problem solved!')   
   G = digraph(Nodes,Images);
  Path=shortestpath(G,1,ind);
  Trajectory_input=zeros(nu,numel(Path)-1);
  X=zeros(n,numel(Path));
  f=[ones(1,m),zeros(1,m)];
  A1=[zeros(m,m), eye(m,m)];
  B1=Uu-epsu_vector;
 A2=[zeros(m,m), -eye(m,m)];
  B2=-(Ul+epsu_vector);
  A3=[-eye(m,m), eye(m,m)];
  B3=c_input;
 A4=[-eye(m,m), -eye(m,m)];
 B4=-c_input;
  A5=[-eye(m,m), zeros(m,m)];
  B5=zeros(m,1);
  A=[A1;A2;A3;A4;A5];
  B=[B1;B2;B3;B4;B5];
  options = optimoptions('linprog','Display','off');
  X(:,1)=X0;

  for j=1:numel(Path)-1
 X1=Tree(:,Path(j));
  X2=Tree(:,Path(j+1));
  Aeq=[zeros(n,m),G_d(X1)];
  Beq=X2-F_d(X1);
  X_opt=linprog(f,A,B,Aeq,Beq,[],[],options);
  Trajectory_input(:,j)=X_opt(m+1:end);
  X(:,j+1)=X2;
  end
 t_planning=toc;
 save("Trajectory_Dubin_Car.mat","X","Trajectory_input","X0","Xsl","Xsu","Xtl","Xtu","XulArray","XuuArray","Ul","Uu","t_planning");  
 warning('planning time is %0.2f sec',t_planning);
else 
toc; 
 end





Xs=zonotope([0.5*(Xsl+Xsu),diag(0.5*(Xsu-Xsl))]);
plot(Xs,[1 2],'g','linewidth',2)
hold on
Xt=zonotope([0.5*(Xtl+Xtu),diag(0.5*(Xtu-Xtl))]);
plot(Xt,[1 2],'b','linewidth',2)

Xu=cell(1,Nu);

for i=1:Nu
Xu{i}=zonotope([CuArray(:,i),diag(0.5*(XuuArray(:,i)-XulArray(:,i)))]);
plot(Xu{i},[1 2],'r','linewidth',2)
end


scatter(Tree(1,1:ind),Tree(2,1:ind),'g')
if dist_T<=1
plot(Tree(1,Path),Tree(2,Path),':ok') 
end



xlim([Xsl(1),Xsu(1)])
ylim([Xsl(2),Xsu(2)])


