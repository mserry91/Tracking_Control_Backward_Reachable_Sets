clc
clear all
close all

load("Trajectory_planar_quadA.mat")


SXu=size(XulArray);
Nu=SXu(2);
n=size(X,1);


Cs=0.5*(Xsl+Xsu);
Ds=0.5*(Xsu-Xsl);
Gs=diag(Ds);


Ct=0.5*(Xtl+Xtu);
Dt=0.5*(Xtu-Xtl);
Gt=diag(Dt);


CuArray=0.5*(XulArray+XuuArray);
DuArray=0.5*(XuuArray-XulArray);
GuArray=zeros(n,n,Nu);
GuiArray=zeros(n,n,Nu);
for j=1:Nu
GuArray(:,:,j)=diag(DuArray(:,j));
end




C_input=0.5*(Uu+Ul);
D_input=0.5*(Uu-Ul);
sizeU=size(Uu);
%input dimension
m=sizeU(1);





numNodes=size(Trajectory_input,2);
 
tic;


alpha=0.99; 
Rx(:,numNodes+1)=Dt-abs(X(:,numNodes+1)-Ct);
for i=numNodes:-1:1
   Distances=Inf(n,Nu+1);
   Distances(:,Nu+1)=Ds-abs(X(:,i)-Cs);
   for j=1:Nu
   [dist,ind]=inf_distance_with_index(X(:,i),CuArray(:,j),DuArray(:,j));
   Distances(ind,j)=alpha*dist;   
   end
   
   for j=1:n
   Rx(j,i)=min(Distances(j,:));
   end

Ru(:,i)=D_input-abs(Trajectory_input(:,i)-C_input);
end

 t_boxes=toc;



tic;
 

T=cell(numNodes+1,1);
Tp=cell(numNodes,1);
Rum=zeros(m,numNodes);

T{numNodes+1}=zonotope(X(:,numNodes+1),diag(Rx(:,numNodes+1)));



% State independent disturbance
Dt=0.01;

er=Dt*[0;0.0;0.0;0.0;0.0;0.0];


D_alpha=diag([1,1,0.9,0.85,0.85,0.9,1,1]);
N_opt_max=3000;


E=zeros(6,1);



for i=numNodes:-1:1
i 
A_k=A_Linearization_Planar_Quad(X(:,i));   
B_k=B_Linearization_Planar_Quad(X(:,i));

Rxb=Rx(:,i);
Rub=Ru(:,i);
hb=[Rxb;Rub];
[H1,H2,H3,H4,H5,H6]=Hessian_Planar_Quad(X(:,i),Rxb,Trajectory_input(:,i),Rub);
E(1)=0.5*dot(hb,H1*hb);
E(2)=0.5*dot(hb,H2*hb);
E(3)=0.5*dot(hb,H3*hb);
E(4)=0.5*dot(hb,H4*hb);
E(5)=0.5*dot(hb,H5*hb);
E(6)=0.5*dot(hb,H6*hb);


Gx=generators(T{i+1});
Gi=pinv(Gx);

[MD,empt_check]=Zonotopic_Minkowski_Difference_BRS(Gx,E+er,Gi);


if empt_check==1
   Volume_BRS=0;  
else   
T{i}=Zonotopic_Intersection_Improved(X(:,i),[A_k\MD,A_k\B_k*diag(Rub)],Rxb);
Volume_BRS=1/norm(pinv(generators(T{i})),inf);
end

Vt=Volume_BRS;
Rum(:,i)=Rub;


for ind_opt=1:N_opt_max
    hb=D_alpha*hb;
    Rxb=hb(1:n);
    Rub=hb(n+1:n+m);  
   [H1,H2,H3,H4,H5,H6]=Hessian_Planar_Quad(X(:,i),Rxb,Trajectory_input(:,i),Rub);
   E(1)=0.5*dot(hb,H1*hb);
   E(2)=0.5*dot(hb,H2*hb);
   E(3)=0.5*dot(hb,H3*hb);
   E(4)=0.5*dot(hb,H4*hb);
   E(5)=0.5*dot(hb,H5*hb);
   E(6)=0.5*dot(hb,H6*hb);
   [MD,empt_check]=Zonotopic_Minkowski_Difference_BRS(Gx,E+er,Gi);
   if empt_check==1
      Volume_BRS=0;
   else
       
      Xbrs=Zonotopic_Intersection_Improved(X(:,i),[A_k\MD,A_k\B_k*diag(Rub)],Rxb);
      Volume_BRS=1/norm(pinv(generators(Xbrs)),inf);
   end

   if Volume_BRS>=Vt
      Vt=Volume_BRS;
      T{i}=Xbrs;
      Rum(:,i)=Rub;
   else
       break;
   end 

end     


 if Vt==0
   warning('optimization failed (zero volume)!!');
   break;
 end 
Tp{i}=zonotope(X(:,i+1),Zonotopic_Minkowski_Difference_BRS(Gx,er,Gi));        

T{i}=reduceUnderApprox(T{i},'sum',20);

end
t_tracking=toc;




X_sample1=0*X;
X_sample1(:,1)=randPoint(T{1});

X_sample2=0*X;
X_sample2(:,1)=randPoint(T{1});

X_sample3=0*X;
X_sample3(:,1)=randPoint(T{1});

tic;
for i=1:numNodes
u_opt=Planar_Quad_Control(X_sample1(:,i),Trajectory_input(:,i),Rum(:,i),Tp{i});    
w_r=-er+2*er.*rand(n,1);
X_sample1(:,i+1)=F_d_planar_quad(X_sample1(:,i))+G_d_planar_quad(X_sample1(:,i))*u_opt;
end    
t_online1=toc;

tic;
for i=1:numNodes
u_opt=Planar_Quad_Control(X_sample2(:,i),Trajectory_input(:,i),Rum(:,i),Tp{i});    
X_sample2(:,i+1)=F_d_planar_quad(X_sample2(:,i))+G_d_planar_quad(X_sample2(:,i))*u_opt;
end    
t_online2=toc;

tic;
for i=1:numNodes
u_opt=Planar_Quad_Control(X_sample3(:,i),Trajectory_input(:,i),Rum(:,i),Tp{i});    
X_sample3(:,i+1)=F_d_planar_quad(X_sample3(:,i))+G_d_planar_quad(X_sample3(:,i))*u_opt;
end    
t_online3=toc;


save("Planar_Quad_Data_For_PlottingA.mat","numNodes","Nu","Cs","Gs","Xsl","Xsu","X","X_sample1","X_sample2","X_sample3","Rx","Ct","Gt","CuArray","GuArray","T","t_online1","t_online2","t_online3")









  
  