function [M] = A_Linearization_Planar_Quad(x,~)

Dt=0.01;
g=9.81;
phi=x(3);
vx=x(4);
vz=x(5);
phid=x(6);

cs=cos(phi);
sn=sin(phi);

M= [1, 0, -Dt*(vz*cs + vx*sn), Dt*cs, -Dt*sn,      0;
    0, 1,  Dt*(vx*cs - vz*sn), Dt*sn,  Dt*cs,      0;
    0, 0,                   1,           0,            0,     Dt;
    0, 0,                  -Dt*g*cs,           1,      Dt*phid,  Dt*vz;
    0, 0,                   Dt*g*sn,    -Dt*phid,            1, -Dt*vx;
    0, 0,                               0,           0,            0,      1];





end
