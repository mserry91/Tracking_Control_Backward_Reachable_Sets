function [xx] = F_d_planar_quad(x)
 
Dt=0.01;
g=9.81;

pxp= x(1);
pzp=x(2);
phip=x(3);
vxp=x(4);
vzp=x(5);
phidp= x(6);


 xx=x;
 xx(1)=pxp+Dt*(vxp*cos(phip)-vzp*sin(phip));
 xx(2)=pzp+Dt*(vxp*sin(phip)+vzp*cos(phip));
 xx(3)=phip+Dt*phidp;
 xx(4)=vxp+Dt*(vzp*phidp-g*sin(phip));
 xx(5)=vzp+Dt*(-vxp*phidp-g*cos(phip));
 xx(6)=phidp;
end

