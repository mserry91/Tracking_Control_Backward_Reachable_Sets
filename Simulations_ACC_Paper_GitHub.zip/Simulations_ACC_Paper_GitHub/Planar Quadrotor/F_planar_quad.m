function [xx] = F_planar_quad(x,u)
 
Dt=0.01;
g=9.81;
m=0.486;
l=0.25;
J=0.00383;


pxp= x(1);
pzp=x(2);
phip=x(3);
vxp=x(4);
vzp=x(5);
phidp= x(6);

cs=cos(phip);
sn=sin(phip);
 xx=x;
 xx(1)=pxp+Dt*(vxp*cs-vzp*sn);
 xx(2)=pzp+Dt*(vxp*sn+vzp*cs);
 xx(3)=phip+Dt*phidp;
 xx(4)=vxp+Dt*(vzp*phidp-g*sn);
 xx(5)=vzp+Dt*(-vxp*phidp-g*cs+(1/m)*(u(1)+u(2)));
 xx(6)=phidp+Dt*((l/J)*(u(1)-u(2)));
end

