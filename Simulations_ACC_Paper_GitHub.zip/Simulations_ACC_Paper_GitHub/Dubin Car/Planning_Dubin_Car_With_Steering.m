% This code is for RRT path planning of the Dubin's car system
%  with safe set (box) Xs,
% unsafe region (union of boxes) Xu, initial point x0 in Xs, 
% and target set (box) Xt. A robustness margin delta is used to inflate and
% deflate the unsafe and safe sets, respectively.

clc
clear all
close all


% system dimension 
n=3;
m=2;

% maximum number of vertices in the random tree
N_v=600;


% parameters for steering function
N_iter=300;
N_alpha=20;
N_extend0=20;
iter_max=200;
iter_cr=100;
dist_target1=0.8;
dist_target2=0.2;
N_extend_inc=5;
N_steps_max=5;


% Initial Condition



%sX=size(X0);





% robustness margins
delta_vector=[0.15;0.15;pi/9];







% safe set Xs

Xsl=[0;0;-pi/2];

Xsu=[5;2;pi/2];


Cs=0.5*(Xsl+Xsu);
Ds=0.5*(Xsu-Xsl)-1.5*delta_vector;
Gs=diag(Ds);







% Target set Xt 

Xtl=[3.5;1.5;-pi/5];
Xtu=[5;2;pi/5];
Ct=0.5*(Xtl+Xtu);
Dt=0.5*(Xtu-Xtl)-delta_vector;
Gt=diag(Dt);


% Unsafe set Xu
XulArray=[1.5;0;-pi/2];
XuuArray=[3;0.5;pi/2];
XulArray=[XulArray, [1.5;1;-pi/2]];
XuuArray=[XuuArray,[2.5;2;pi/2]];
XulArray=[XulArray, [3.5;0;-pi/2]];
XuuArray=[XuuArray,[4.5;1;pi/2]];

sXu=size(XulArray);
Nu=sXu(2);

CuArray=0.5*(XulArray+XuuArray);
DuArray=0.5*(XuuArray-XulArray)+delta_vector;
GuArray=zeros(n,n,Nu);
GuiArray=zeros(n,n,Nu);

for j=1:Nu
GuArray(:,:,j)=diag(DuArray(:,j));
end





% control input set U
uxl=-0.08;
uxu=0.08;

uyl=-0.05;
uyu=0.05;

epsu_vector=[0.02;0.02]; % parameter for deflating input set

Ul=[uxl;uyl]+epsu_vector;

Uu=[uxu;uyu]-epsu_vector;
%input dimension
sizeU=size(Uu);
nu=sizeU(1);

c_input=0.5*(Ul+Uu);
G_input_def=0.5*((Uu-epsu_vector)-(Ul+epsu_vector));


% initial condition

initial_safety=0;
while initial_safety==0
 % generating a random sample 
 X0=Xsl+(Xsu-Xsl).*rand(n,1);
initial_safety=Safety_Check(X0,Cs,Ds,CuArray,DuArray);
end

X0=[0.5;1.5;-pi/4];
%X0=[0.5;0.5;-pi/4];





%initializing the RRT Tree and associated tree structures
Tree=zeros(n,N_v);
Nodes=ones(1,N_v);
Images=ones(1,N_v);
Controls=cell(N_v);



ind=1;
ind_iter=0;
Tree(:,1)=X0; % adding initial point to the tree.

dist_T=300;








tic

while  ind<N_v 
   ind 
 % generating a random sample 
   sample_safety=0;
while sample_safety==0
 
    % generating a random sample 
      if ind<0.7*N_v
         x_sample=(Xsl+delta_vector)+((Xsu-delta_vector)-(Xsl+delta_vector)).*rand(n,1);
         dist_target=dist_target1;

      else
         x_sample=(Xtl+delta_vector)+((Xtu-delta_vector)-(Xtl+delta_vector)).*rand(n,1);
        dist_target=dist_target2;
      
      end

      sample_safety=Safety_Check(x_sample,Cs,Ds,CuArray,DuArray);
end

 dist=100*norm(Xsu-Xsl,inf);
 
 for ind_dist=1:ind
      
    if  Safety_Check(Tree(:,ind_dist),Cs,Ds,CuArray,DuArray)==1
        dr=norm(x_sample-Tree(:,ind_dist),inf); 
        if dr<=dist
            ind_near=ind_dist;
            dist=dr;
        end
    end
  end
 
 
 x_near=Tree(:,ind_near);
 Rx0=Safety_Radius(x_near,Cs,Ds,CuArray,DuArray);
 Rx0n=norm(Rx0,inf);
 Rx=(0.6/(max([Rx0n,1])))*Rx0;
 x_new_p=ClosestPoint(x_sample,x_near,Rx);
 
 N_extend=N_extend0;
 u_ast=Control_Synthesizer_With_Constraints_Dubin_Car(n,m,N_extend,N_alpha,N_iter,iter_cr,iter_max,x_near,x_new_p,dist_target,Ul,Uu);
 dist_tt=norm(x_new_p-Extend_Dubin_Car(x_near,N_extend,u_ast));
 %dist_tt=norm(Proj_Mat*(x_new_p-Extend_Dubin_Car(x_near,N_extend,u_ast)));
  ind_steps=1;
  while dist_tt>dist_target && ind_steps<=N_steps_max
  ind_steps=ind_steps+1;
  N_extend=N_extend+N_extend_inc;
   u_ast=Control_Synthesizer_With_Constraints_Dubin_Car(n,m,N_extend,N_alpha,N_iter,iter_cr,iter_max,x_near,x_new_p,dist_target,Ul,Uu);
  dist_tt=norm(x_new_p-Extend_Dubin_Car(x_near,N_extend,u_ast));
   %dist_tt=norm(Proj_Mat*(x_new_p-Extend_Dubin_Car(x_near,N_extend,u_ast)));
  end
 
 [x_new_c]=Extend_Dubin(x_near,u_ast,N_extend,Cs,Ds,CuArray,DuArray);
 
  % rewiring step
 for j=max([1,ind_near-40]):ind_near-1
     if  min(Safety_Radius(Tree(:,j),Cs,Ds,CuArray,DuArray)-abs(x_new_p-Tree(:,j)))>0 %&&  norm(x_new_p-Tree(:,j),inf)<=5*norm(Rx,inf)
          u_ast_t=Control_Synthesizer_With_Constraints_Dubin_Car(n,m,N_extend,N_alpha,N_iter,iter_cr,iter_max,Tree(:,j),x_new_p,dist_target,Ul,Uu);
          dist_ttt=norm(x_new_p-Extend_Dubin_Car(Tree(:,j),N_extend,u_ast_t));
           %dist_ttt=norm(Proj_Mat*(x_new_p-Extend_Dubin_Car(Tree(:,j),N_extend,u_ast_t)));

          [x_t]=Extend_Dubin(Tree(:,j),u_ast_t,N_extend,Cs,Ds,CuArray,DuArray);

         if dist_ttt<=dist_target && isempty(x_t)==0
            ind_near=j;
            x_near=Tree(:,ind_near);
            u_ast=u_ast_t;
            x_new_c=x_t;
            %warning('wiring!!')
            break;
         end    
     end
 end
 
 
 
 
 
 
 
if isempty(x_new_c)==0 
 ind=ind+1;
 Tree(:,ind)=x_new_c;
 Nodes(ind-1)=ind_near;
 Images(ind-1)=ind;
 Controls{ind-1}= u_ast;
 dist_T=norm(Gt\(x_new_c-Ct),inf);
 end
 
 if dist_T<1
 warning('Problem solved!')
 break;
 end
 
 



    
end    
    
    






  if dist_T<1
   G = digraph(Nodes,Images);
  Path=shortestpath(G,1,ind);
   indx=1;
  Trajectory_input=[];
  for i=length(Path):-1:2
  indx=Path(i); 
  j=indx-1;
  Trajectory_input=[Controls{j},Trajectory_input];
  end
  N=size(Trajectory_input,2);
  X=zeros(n,N+1);
  X(:,1)=X0;
  for k=1:N 
  X(:,k+1)=F_Dubin_Car(X(:,k),Trajectory_input(:,k));      
  end  
  t_planning=toc;
  Ul=Ul-epsu_vector;
  Uu=Uu+epsu_vector;
  save("Trajectory_Dubin_CarA.mat","X","Trajectory_input","X0","Xsl","Xsu","Xtl","Xtu","XulArray","XuuArray","Ul","Uu","t_planning");  

  else
      toc;
  end

Xs=zonotope([0.5*(Xsl+Xsu),diag(0.5*(Xsu-Xsl))]);
plot(Xs,[1 2],'g','linewidth',2)
hold on
Xt=zonotope([0.5*(Xtl+Xtu),diag(0.5*(Xtu-Xtl))]);
plot(Xt,[1 2],'b','linewidth',2)

Xu=cell(1,Nu);

for i=1:Nu
Xu{i}=zonotope([CuArray(:,i),diag(0.5*(XuuArray(:,i)-XulArray(:,i)))]);
plot(Xu{i},[1 2],'r','linewidth',2)
end



scatter(Tree(1,1:ind),Tree(2,1:ind),'og')
if dist_T<=1
plot(X(1,:),X(2,:),':or')
plot(Tree(1,Path),Tree(2,Path),':ok')
end


xlim([Xsl(1),Xsu(1)])
ylim([Xsl(2),Xsu(2)])



function [x_new] = Extend_Dubin(x_near,u_ast,N_extend,Cs,Ds,CuArray,DuArray)

 for j=1:N_extend
     x_new_p=F_Dubin_Car(x_near,u_ast(:,j));
     margin=Safety_Check(x_new_p,Cs,Ds,CuArray,DuArray);
 if margin==1
    x_new=x_new_p;
    x_near=x_new_p;
 else
     x_new=[];
     break;
 end
    
    
 end
  
end


