function [A] = B_Linearization_Planar_Quad(~)

Dt=0.01;
%g=9.81;
m=0.486;
l=0.25;
J=0.00383;

A=Dt*[0 0;
      0 0;
      0 0;
      0 0;
      (1/m) (1/m);
      (l/J) -(l/J)];
end

