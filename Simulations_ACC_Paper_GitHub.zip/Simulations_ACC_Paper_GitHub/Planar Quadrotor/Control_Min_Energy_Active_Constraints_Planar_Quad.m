function [u_ast_Array] = Control_Min_Energy_Active_Constraints_Planar_Quad(n,m,N_extend,N_alpha,X0,x_sample,Ul,Uu,u_ast_Array_in)


tol_const=1e-9;


Xc=zeros(n,N_extend+1);
Xc(:,1)=X0;

for i=1:N_extend
Xc(:,i+1)=F_planar_quad(Xc(:,i),u_ast_Array_in(:,i));   
end


A_Array=zeros(n,n,N_extend);
B_Active_Constraints_Array=zeros(m,m,N_extend);
B_Array=zeros(n,m,N_extend);
B0=B_Linearization_Planar_Quad();
c_Array=zeros(n,N_extend);

for k=1:N_extend
A_Array(:,:,k)=A_Linearization_Planar_Quad(Xc(:,k),u_ast_Array_in(:,k));
B_Active_Constraints_Array(:,:,k)=eye(m,m);

for j=1:m
  if min([abs(u_ast_Array_in(j,k)-Uu(j)),abs(u_ast_Array_in(j,k)-Ul(j))])<=tol_const  
  B_Active_Constraints_Array(j,j,k)=0;
  end
end
B_Array(:,:,k)=B0*B_Active_Constraints_Array(:,:,k);  
end    



% controllability matrix
Y=zeros(n,N_extend*m);
R=eye(n,n);
for j=1:N_extend
Y(:,(j-1)*m+1:j*m)=R*B_Array(:,:,N_extend-j+1);    
R=R*A_Array(:,:,N_extend-j+1);
end

W=Y*transpose(Y);


  


W_ast=pinv(W);
 

W_basis=orth(W);

r=zeros(n,1);
M=eye(n,n);
for j=1:N_extend    
r=r+M*c_Array(:,N_extend-j+1);
M=M*A_Array(:,:,N_extend-j+1);
end

v=x_sample-Xc(:,N_extend+1);

v_p=zeros(n,1);
for j=1:size(W_basis,2)
e=W_basis(:,j);
v_p=v_p+dot(v,e)*e;
end

Delta_u_ast_Array=zeros(m,N_extend);




for j=1:N_extend
%Delta_u_ast_Array(:,j)=transpose(Y(:,(N_extend-j)*m+1:(N_extend-j+1)*m))*W_ast*v_p;
Delta_u_ast_Array(:,j)=B_Active_Constraints_Array(:,:,j)*transpose(Y(:,(N_extend-j)*m+1:(N_extend-j+1)*m))*W_ast*v_p;
end


%umax=norm(reshape(Delta_u_ast_Array,[],1),inf);
%scale=1/umax;    
%Delta_u_norm_ast_Array=scale*Delta_u_ast_Array;
Delta_u_norm_ast_Array=Delta_u_ast_Array;


alpha_opt=Inf;
for k=1:N_extend

    for j=1:m
    if Delta_u_norm_ast_Array(j,k)>0
        q=(Uu(j)-u_ast_Array_in(j,k))/Delta_u_norm_ast_Array(j,k);
        
    elseif Delta_u_norm_ast_Array(j,k)<0
        q=(Ul(j)-u_ast_Array_in(j,k))/Delta_u_norm_ast_Array(j,k);
    else
    q=Inf;
    end    
        alpha_opt=min([alpha_opt,q]);
    end
end

%alpha=min([alpha_opt,1]);
Alpha_Array=linspace(0,alpha_opt,N_alpha);
yp=Extend_Planar_Quad(X0,N_extend,u_ast_Array_in);
Dist_p=norm(yp-x_sample);
Dist_c_Array=zeros(1,N_alpha);


 alpha_1=Alpha_Array(N_alpha);
 alpha_2=Alpha_Array(N_alpha-1);
 
 u_ast_Array_1=u_ast_Array_in+alpha_1*Delta_u_norm_ast_Array;
 Dist_1= norm(Extend_Planar_Quad(X0,N_extend,u_ast_Array_1)-x_sample);
 
 u_ast_Array_2=u_ast_Array_in+alpha_2*Delta_u_norm_ast_Array;
 Dist_2=norm(Extend_Planar_Quad(X0,N_extend,u_ast_Array_2)-x_sample);
 
if Dist_1<=Dist_2
Dist_c=Dist_1;
alpha_ind=N_alpha;


else

for i=1:N_alpha
u_ast_Array=u_ast_Array_in+Alpha_Array(i)*Delta_u_norm_ast_Array;
yp=Extend_Planar_Quad(X0,N_extend,u_ast_Array);
Dist_c_Array(i)=norm(yp-x_sample);
end


%figure 
%plot(Alpha_Array,Dist_c_Array,':ok')

[Dist_c,alpha_ind] = min(Dist_c_Array);

end



if Dist_c<Dist_p
u_ast_Array=u_ast_Array_in+Alpha_Array(alpha_ind)*Delta_u_norm_ast_Array;
else
%warning('Objective function not decreasing!!');    
%Alpha_Array(alpha_ind)
u_ast_Array=u_ast_Array_in;
end

end



